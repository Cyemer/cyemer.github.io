#!/bin/bash
if command -v java >/dev/null 2>&1; then
    java -jar "$(dirname "$0")/loader.jar"
else
    echo "Java not found. Please install Java." && sleep 3
fi
